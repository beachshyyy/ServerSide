const testMiddleware = () => {
    return (req, res, next) => {
        console.log("Authen")
        next()
    }
}

export default testMiddleware