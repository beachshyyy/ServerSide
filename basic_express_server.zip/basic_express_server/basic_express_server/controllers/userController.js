import userService from "../services/userService.js"
import * as z from "zod"

const UserDTO = z.object({
  name: z.string(),
  age: z.int(),
  phone: z.optional(z.string())
})

const userController = {
  getAllUsers: async (req, res) => {
    const users = await userService.getAllUsers()
    res.status(200).json(users)
  },
  getUserById: async (req, res) => {
    const id = req.params.id
    const user = await userService.getUserById(id)
    if (!user) {
      res.status(404).json({ 
        message: "Not Found" })
    }
    res.status(200).json(user)
  },
  create: async (req, res) => {
    try {
      const { name, age, phone } = req.body
      if (!name) {
        res.status(400).json({
          message: "name is null"
        })
      }
      if (!age) {
        res.status(400).json({
          message: "age is null"
        })
      }
      if (typeof age !== number) {
        res.status(400).json({
          message: "age is not number"
        })
      }
      const user = await userService.create(name, age, phone)
      res.status(201).json(user)
    } catch (err) {
      res.status(500).json(err)
    }
  }
}

export default userController